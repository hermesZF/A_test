﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Crevis.VirtualFG40Library;
using System.Runtime.InteropServices;
using System.Drawing.Imaging;

namespace Callback_Normal_Color
{
    public partial class Callback_Normal_Color : Form
    {
        VirtualFG40Library _virtualFG40 = new VirtualFG40Library();
        Int32 _hDevice = 0;
        Int32 _width = 0;
        Int32 _height = 0;
        double _exptime = 0;
        Int32 _bufferSize = 0;
        Int32 _pxlFmt = 0;
        Boolean _isOpen = false;
        Boolean _isGrabed = false;
        Boolean m_IsGrabed = false;        
        IntPtr _cvtImage = new IntPtr();       
        IntPtr _userdata = new IntPtr();
        GCHandle _gch;
        Bitmap rawbitmap;
        float mscale;
        public Callback_Normal_Color()
        {
            InitializeComponent();
        }

        private void Callback_Normal_Color_Load(object sender, EventArgs e)
        {
            Int32 status = VirtualFG40Library.MCAM_ERR_SUCCESS;
            mscale = 1.0f;
            try
            {
                //System Initialize
                status = _virtualFG40.InitSystem();
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("System Initialize failed : {0}", status));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            btn_Open.Enabled = true;
            btn_Close.Enabled = false;
            btn_Grab.Enabled = false;
            btn_Play.Enabled = false;
            btn_Stop.Enabled = false;
            btn_WBOnce.Enabled = false;
            scaleFactor.Enabled = false;
            scaleFactor.Value = 100;
            bnSetExp.Enabled = false;
            button1.Enabled = false;
        }

        private void Callback_Normal_Color_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (_isOpen == true)
            {
                if (_cvtImage != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(_cvtImage);
                    _cvtImage = IntPtr.Zero;
                }

                _gch.Free();

                // Close Device
                _virtualFG40.CloseDevice(_hDevice);
            }

            _virtualFG40.FreeSystem();
        }

        private void btn_Open_Click(object sender, EventArgs e)
        {
            Int32 status = VirtualFG40Library.MCAM_ERR_SUCCESS;
            UInt32 camNum = 0;

            try
            {
                // Update Device List
                status = _virtualFG40.UpdateDevice();
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    _virtualFG40.FreeSystem();
                    throw new Exception(String.Format("Update Device list failed : {0}", status));
                }

                status = _virtualFG40.GetAvailableCameraNum(ref camNum);
                if (camNum <= 0)
                {
                    _virtualFG40.FreeSystem();
                    throw new Exception("The camera can not be connected.");
                }
                // camera open
                status = _virtualFG40.OpenDevice(0, ref _hDevice);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    _virtualFG40.FreeSystem();
                    throw new Exception(String.Format("Open device failed : {0}", status));
                }

                _isOpen = true;

                // Call Set Feature
                SetFeature();

                // Get Width
                status = _virtualFG40.GetIntReg(_hDevice, VirtualFG40Library.MCAM_WIDTH, ref _width);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Read Register failed : {0}", status));
                }

                // Get Height
                status = _virtualFG40.GetIntReg(_hDevice, VirtualFG40Library.MCAM_HEIGHT, ref _height);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Read Register failed : {0}", status));
                }
                //status = _virtualFG40.GetIntReg(_hDevice, VirtualFG40Library.MCAM_PIXEL_FORMAT, ref _pxlFmt);
                //if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                //{
                //    throw new Exception(String.Format("Read Register failed : {0}", status));
                //}

                // Get Exposure Time
                status = _virtualFG40.GetFloatReg(_hDevice, VirtualFG40Library.MCAM_EXPOSURE_TIME, ref _exptime);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Read Register failed : {0}", status));
                }
                dev_exp.Text = _exptime.ToString("##.##");

                // Image buffer allocation
                _bufferSize = _width * _height;
                
                // Display Image buffer allocation
                _cvtImage = Marshal.AllocHGlobal(_bufferSize * 3);

                // Crevis Callback Function  
                VirtualFG40Library.CallbackFunc vfgCallback = new VirtualFG40Library.CallbackFunc(OnCallback);
                _virtualFG40.SetCallbackFunction(_hDevice, VirtualFG40Library.EVENT_NEW_IMAGE, vfgCallback, _userdata);
                _gch = GCHandle.Alloc(vfgCallback);

                pictureBox_Display.Image = new Bitmap(_width, _height, PixelFormat.Format24bppRgb);
                pictureBox_Display.Width = _width;
                pictureBox_Display.Height = _height;
                /*btn_WBOnce.Enabled = (_pxlFmt >5 );*/
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            btn_Open.Enabled = false;
            btn_Close.Enabled = true;
            btn_Grab.Enabled = true;
            btn_Play.Enabled = true;
            btn_Stop.Enabled = true;
            btn_WBOnce.Enabled = true;
            scaleFactor.Enabled = true;
            bnSetExp.Enabled = true;
            button1.Enabled = true;
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            if (_isOpen == true)
            {
                if (_cvtImage != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(_cvtImage);
                    _cvtImage = IntPtr.Zero;
                }

                _gch.Free();

                // Close Device
                _virtualFG40.CloseDevice(_hDevice);

                _isOpen = false;
            }

            btn_Open.Enabled = true;
            btn_Close.Enabled = false;
            btn_Grab.Enabled = false;
            btn_Play.Enabled = false;
            btn_Stop.Enabled = false;
            btn_WBOnce.Enabled = false;
            pictureBox_Display.Image = null;
            pictureBox_Display.Width = 868;
            pictureBox_Display.Height = 720;
            scaleFactor.Enabled = false;
            bnSetExp.Enabled = false;
            button1.Enabled = false;
        }

        private void btn_Grab_Click(object sender, EventArgs e)
        {
            // 1. Excute Acquisition Start command	
            // 2. Waiting Grab Finish
            // 3. Excute Acquisition Stop command          

            Int32 status = VirtualFG40Library.MCAM_ERR_SUCCESS;

            try
            {
                // Acqusition Start
                status = _virtualFG40.AcqStart(_hDevice);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Acqusition Start failed : {0}", status));
                }

                while (true)
                {
                    if (_isGrabed == true)
                        break;
                }

                // Acqusition Stop
                status = _virtualFG40.AcqStop(_hDevice);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Acqusition Stop failed : {0}", status));
                }

                _isGrabed = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            btn_Open.Enabled = false;
            btn_Close.Enabled = true;
            btn_Grab.Enabled = true;
            btn_Play.Enabled = true;
            btn_Stop.Enabled = true;           
        }

        private void btn_Play_Click(object sender, EventArgs e)
        {
            // 1. Change Acquisition Mode : Continuous
            // 2. Excute Acqusition Start Command

            Int32 status = VirtualFG40Library.MCAM_ERR_SUCCESS;

            try
            {
                // Change Acqusition Mode
                status = _virtualFG40.SetEnumReg(_hDevice, VirtualFG40Library.MCAM_ACQUISITION_MODE, VirtualFG40Library.ACQUISITION_MODE_CONTINUOUS);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Write Register failed : {0}", status));
                }

                // Acqusition Start
                status = _virtualFG40.AcqStart(_hDevice);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Acqusition Start failed : {0}", status));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            btn_Open.Enabled = false;
            btn_Close.Enabled = false;
            btn_Grab.Enabled = false;
            btn_Play.Enabled = false;
            btn_Stop.Enabled = true;
        }

        private void btn_Stop_Click(object sender, EventArgs e)
        {
            // 1. Excute Acqusition Stop Command 

            Int32 status = VirtualFG40Library.MCAM_ERR_SUCCESS;

            try
            {
                // Acqusition Stop
                status = _virtualFG40.AcqStop(_hDevice);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Acqusition Start failed : {0}", status));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            btn_Open.Enabled = false;
            btn_Close.Enabled = true;
            btn_Grab.Enabled = true;
            btn_Play.Enabled = true;
            btn_Stop.Enabled = true;
        }

        private void btn_WBOnce_Click(object sender, EventArgs e)
        {
            Int32 status = VirtualFG40Library.MCAM_ERR_SUCCESS;

            try
            {
                // BalanceWhiteAuto
                status = _virtualFG40.SetEnumReg(_hDevice, VirtualFG40Library.MCAM_BALANCE_WHITE_AUTO, VirtualFG40Library.BALANCE_WHITE_AUTO_ONCE);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Write Register failed : {0}", status));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }        

        private void SetFeature()
        {
            Int32 status = VirtualFG40Library.MCAM_ERR_SUCCESS;

            try
            {
                // Set Trigger Mode
                status = _virtualFG40.SetEnumReg(_hDevice, VirtualFG40Library.MCAM_TRIGGER_MODE, VirtualFG40Library.TRIGGER_MODE_OFF);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Write Register failed : {0}", status));
                }

                //// Set PixelFormat
                //status = _virtualFG40.SetEnumReg(_hDevice, VirtualFG40Library.MCAM_PIXEL_FORMAT, VirtualFG40Library.PIXEL_FORMAT_BAYERRG8);
                //if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                //{
                //    throw new Exception(String.Format("Write Register failed : {0}", status));
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }        

        public Int32 OnCallback(Int32 EventID, IntPtr pImage, IntPtr userData)
        {
            if (EventID != VirtualFG40Library.EVENT_NEW_IMAGE)
                return -1;            

            Int32 bitsPerPixel = 0;
            Int32 stride = 0;
            //Bitmap bitmap;
            PixelFormat pixelFormat = PixelFormat.Format24bppRgb;

            _virtualFG40.CvtColor(pImage, _cvtImage, _width, _height, VirtualFG40Library.CV_BayerRG2RGB);
            
            //color
            bitsPerPixel = 24;
            stride = (Int32)((_width * bitsPerPixel + 7) / 8);
            rawbitmap = new Bitmap(_width, _height, stride, pixelFormat, _cvtImage);

            pictureBox_Display.Image = rawbitmap;


            _isGrabed = true;
 
            return 0;            
        }

        private void bnSetExp_Click(object sender, EventArgs e)
        {
            Int32 status = VirtualFG40Library.MCAM_ERR_SUCCESS;
            _exptime = Convert.ToDouble(dev_exp.Text);
            _virtualFG40.SetFloatReg(_hDevice, VirtualFG40Library.MCAM_EXPOSURE_TIME, _exptime);
            
            if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
            {
                throw new Exception(String.Format("Read Register failed : {0}", status));
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (rawbitmap != null)
                rawbitmap.Save("color.bmp");
        }

        private void scaleFactor_ValueChanged(object sender, EventArgs e)
        {
            mscale = Convert.ToSingle(scaleFactor.Value) / Convert.ToSingle(scaleFactor.Maximum);
            if (pictureBox_Display.Image != null)
            {
                pictureBox_Display.Width = Convert.ToInt16( rawbitmap.Width * mscale);
                pictureBox_Display.Height = Convert.ToInt16(rawbitmap.Height * mscale);
            }
        }
    }
}
