﻿namespace Callback_Normal_Color
{
    partial class Callback_Normal_Color
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_WBOnce = new System.Windows.Forms.Button();
            this.btn_Stop = new System.Windows.Forms.Button();
            this.btn_Play = new System.Windows.Forms.Button();
            this.btn_Grab = new System.Windows.Forms.Button();
            this.btn_Close = new System.Windows.Forms.Button();
            this.btn_Open = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dev_exp = new System.Windows.Forms.TextBox();
            this.bnSetExp = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.displayout = new System.Windows.Forms.FlowLayoutPanel();
            this.pictureBox_Display = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.scaleFactor = new System.Windows.Forms.NumericUpDown();
            this.displayout.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Display)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scaleFactor)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_WBOnce
            // 
            this.btn_WBOnce.Location = new System.Drawing.Point(890, 154);
            this.btn_WBOnce.Name = "btn_WBOnce";
            this.btn_WBOnce.Size = new System.Drawing.Size(90, 23);
            this.btn_WBOnce.TabIndex = 14;
            this.btn_WBOnce.Text = "WB Once";
            this.btn_WBOnce.UseVisualStyleBackColor = true;
            this.btn_WBOnce.Click += new System.EventHandler(this.btn_WBOnce_Click);
            // 
            // btn_Stop
            // 
            this.btn_Stop.Location = new System.Drawing.Point(890, 124);
            this.btn_Stop.Name = "btn_Stop";
            this.btn_Stop.Size = new System.Drawing.Size(90, 23);
            this.btn_Stop.TabIndex = 12;
            this.btn_Stop.Text = "Stop";
            this.btn_Stop.UseVisualStyleBackColor = true;
            this.btn_Stop.Click += new System.EventHandler(this.btn_Stop_Click);
            // 
            // btn_Play
            // 
            this.btn_Play.Location = new System.Drawing.Point(890, 95);
            this.btn_Play.Name = "btn_Play";
            this.btn_Play.Size = new System.Drawing.Size(90, 23);
            this.btn_Play.TabIndex = 13;
            this.btn_Play.Text = "Play";
            this.btn_Play.UseVisualStyleBackColor = true;
            this.btn_Play.Click += new System.EventHandler(this.btn_Play_Click);
            // 
            // btn_Grab
            // 
            this.btn_Grab.CausesValidation = false;
            this.btn_Grab.Location = new System.Drawing.Point(890, 66);
            this.btn_Grab.Name = "btn_Grab";
            this.btn_Grab.Size = new System.Drawing.Size(90, 23);
            this.btn_Grab.TabIndex = 11;
            this.btn_Grab.Text = "Grab";
            this.btn_Grab.UseVisualStyleBackColor = true;
            this.btn_Grab.Click += new System.EventHandler(this.btn_Grab_Click);
            // 
            // btn_Close
            // 
            this.btn_Close.Location = new System.Drawing.Point(890, 37);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(90, 23);
            this.btn_Close.TabIndex = 9;
            this.btn_Close.Text = "Close";
            this.btn_Close.UseVisualStyleBackColor = true;
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // btn_Open
            // 
            this.btn_Open.Location = new System.Drawing.Point(890, 8);
            this.btn_Open.Name = "btn_Open";
            this.btn_Open.Size = new System.Drawing.Size(90, 23);
            this.btn_Open.TabIndex = 10;
            this.btn_Open.Text = "Open";
            this.btn_Open.UseVisualStyleBackColor = true;
            this.btn_Open.Click += new System.EventHandler(this.btn_Open_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(893, 191);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 12);
            this.label1.TabIndex = 15;
            this.label1.Text = "Exposure Time (ms)";
            // 
            // dev_exp
            // 
            this.dev_exp.Location = new System.Drawing.Point(890, 206);
            this.dev_exp.Name = "dev_exp";
            this.dev_exp.Size = new System.Drawing.Size(88, 22);
            this.dev_exp.TabIndex = 16;
            // 
            // bnSetExp
            // 
            this.bnSetExp.Location = new System.Drawing.Point(890, 234);
            this.bnSetExp.Name = "bnSetExp";
            this.bnSetExp.Size = new System.Drawing.Size(90, 23);
            this.bnSetExp.TabIndex = 17;
            this.bnSetExp.Text = "Set Exp";
            this.bnSetExp.UseVisualStyleBackColor = true;
            this.bnSetExp.Click += new System.EventHandler(this.bnSetExp_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(890, 280);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 23);
            this.button1.TabIndex = 18;
            this.button1.Text = "Save bmp";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // displayout
            // 
            this.displayout.AutoScroll = true;
            this.displayout.Controls.Add(this.pictureBox_Display);
            this.displayout.Location = new System.Drawing.Point(5, 5);
            this.displayout.Name = "displayout";
            this.displayout.Size = new System.Drawing.Size(878, 768);
            this.displayout.TabIndex = 19;
            // 
            // pictureBox_Display
            // 
            this.pictureBox_Display.Location = new System.Drawing.Point(3, 3);
            this.pictureBox_Display.Name = "pictureBox_Display";
            this.pictureBox_Display.Size = new System.Drawing.Size(861, 715);
            this.pictureBox_Display.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Display.TabIndex = 9;
            this.pictureBox_Display.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(888, 328);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 12);
            this.label2.TabIndex = 20;
            this.label2.Text = "Zoom";
            // 
            // scaleFactor
            // 
            this.scaleFactor.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.scaleFactor.Location = new System.Drawing.Point(890, 343);
            this.scaleFactor.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.scaleFactor.Name = "scaleFactor";
            this.scaleFactor.Size = new System.Drawing.Size(90, 22);
            this.scaleFactor.TabIndex = 21;
            this.scaleFactor.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.scaleFactor.ValueChanged += new System.EventHandler(this.scaleFactor_ValueChanged);
            // 
            // Callback_Normal_Color
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(989, 785);
            this.Controls.Add(this.scaleFactor);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.displayout);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.bnSetExp);
            this.Controls.Add(this.dev_exp);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_WBOnce);
            this.Controls.Add(this.btn_Stop);
            this.Controls.Add(this.btn_Play);
            this.Controls.Add(this.btn_Grab);
            this.Controls.Add(this.btn_Close);
            this.Controls.Add(this.btn_Open);
            this.Name = "Callback_Normal_Color";
            this.Text = "Callback_Normal_Color";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Callback_Normal_Color_FormClosed);
            this.Load += new System.EventHandler(this.Callback_Normal_Color_Load);
            this.displayout.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Display)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scaleFactor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_WBOnce;
        internal System.Windows.Forms.Button btn_Stop;
        internal System.Windows.Forms.Button btn_Play;
        internal System.Windows.Forms.Button btn_Grab;
        internal System.Windows.Forms.Button btn_Close;
        internal System.Windows.Forms.Button btn_Open;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox dev_exp;
        private System.Windows.Forms.Button bnSetExp;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.FlowLayoutPanel displayout;
        internal System.Windows.Forms.PictureBox pictureBox_Display;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown scaleFactor;
    }
}

